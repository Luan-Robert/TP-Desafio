package br.unisanta.desafio.model

data class Desafio(
    val nome: String = "",
    val valor: String = "",
    val url: String = ""
)
