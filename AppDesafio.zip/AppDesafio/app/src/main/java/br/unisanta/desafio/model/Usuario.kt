package br.unisanta.desafio.model

data class Usuario(
    val nome: String = "",
    val email: String = "",
    val senha: String = ""
)